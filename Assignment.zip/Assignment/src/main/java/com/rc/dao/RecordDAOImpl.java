package com.rc.dao;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.rc.entity.Student;
@Repository("studDAO")
public class RecordDAOImpl implements RecordDAO {
	private static final String INSERT_STUDENT = "INSERT INTO STUDENTS VALUES(?,?,?,?)";
	private static final String SHOW_STUDENT = "SELECT * FROM STUDENTS ";
	private static final String UPDATE_STUDENT = "UPDATE STUDENTS SET NAME=?,GENDER=? WHERE ID=?";

	@Autowired
	private JdbcTemplate jt;

	

	public List<Map<String, Object>> showAllRecords() {
		List<Map<String, Object>> list = jt.queryForList(SHOW_STUDENT);
		return list;
	}
	
		
	public int insert(Student stud) {
		int cnt = jt.update(INSERT_STUDENT, stud.getId(), stud.getName(), stud.getGender(), stud.getAddr());
		return cnt;
	}

	public int updateRecord(Student stud) {
		int cnt = jt.update(UPDATE_STUDENT, stud.getName(), stud.getGender(),stud.getId());
		return cnt;
	}

}


	


