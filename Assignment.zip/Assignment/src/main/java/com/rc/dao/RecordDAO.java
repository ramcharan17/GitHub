package com.rc.dao;

import java.util.List;
import java.util.Map;
import com.rc.entity.Student;

public interface RecordDAO {
	public int insert(Student stud);

	public List<Map<String, Object>> showAllRecords();

    public int updateRecord(Student stud);

}
