package com.rc.service;

import java.util.List;
import java.util.Map;

import com.rc.entity.Student;

public interface StudentService {
	public int insertService(Student stud);

	public List<Map<String, Object>> showAllRecordsService();

	public int updateRecordService(Student stud);

}
