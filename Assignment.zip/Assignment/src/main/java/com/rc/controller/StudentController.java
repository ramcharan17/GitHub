package com.rc.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.rc.entity.Student;

import com.rc.service.StudentServiceImpl;

@Controller
public class StudentController {

	@Autowired
	private StudentServiceImpl service;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String showHomePage() {
		System.out.println("welcome to Student Data");
		return "home";
	}

	@RequestMapping(value = "add", method = RequestMethod.POST)
	public String insertServ(@ModelAttribute("Student") Student stud) {
		service.insert(stud);
		return "addStudent";
		/*
		 * result=service.insertService(stud); if (result > 0) map.addAttribute("msg",
		 * stud); else map.addAttribute("msg", null); return "view";
		 */

	}

	@RequestMapping(value = "showdata", method = RequestMethod.GET)
	public String getAllRecords(ModelMap map) {
		List<Map<String, Object>> list = service.showAllRecords();
		map.addAttribute("list", list);
		return ("showStudentData");
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String updateRecord(@ModelAttribute("Student") Student stud) {
		service.updateRecord(stud);
		return "EditStudent";
	}
}
