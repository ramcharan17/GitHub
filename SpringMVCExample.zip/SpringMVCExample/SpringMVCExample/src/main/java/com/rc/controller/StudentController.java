package com.rc.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import com.rc.entity.Student;

import com.rc.service.StudentServiceImpl;

@Controller
public class StudentController {

	@Autowired
	private StudentServiceImpl service;

	@RequestMapping(value = "/studenthome", method = RequestMethod.GET)
	public String showHomePage() {
		System.out.println("welcome to Student Data");
		return "studenthome";
	}

	@RequestMapping(value = "/addstudent", method = RequestMethod.GET)
	public String showAddStudentPage() {

		return "addStudent";
	}

	@RequestMapping(value = "add", method = RequestMethod.POST)
	public String insertServ(@ModelAttribute("student") Student stud, Model model) {
		System.out.println(stud.toString());
		int result = service.insert(stud);
		if (result == 1) {
			model.addAttribute("result", "Student data inserted");
			return "success";
		} else {
			return "failure";
		}
	}

	@RequestMapping(value = "/showdata", method = RequestMethod.GET)

	public String getAllRecords(ModelMap map) {
		List<Map<String, Object>> list = service.showAllRecords();
		map.addAttribute("list", list);
		return ("showStudentData");
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public String updateRecord(@RequestParam String id, Model model) {
		System.out.println("id value "+id);
		Student student = service.getStudent(Integer.parseInt(id));
		model.addAttribute("student", student);
		
		return "editStudent";
		}
	@RequestMapping(value = "updateRecord", method = RequestMethod.POST)
	public String updateStudent(@ModelAttribute("student") Student stud, Model model) {
		System.out.println(stud.toString());
		int result = service.updateRecord(stud);
		if (result == 1) {
			model.addAttribute("result", "Student data updated");
			return "success";
		} else {
			return "failure";
		}
	}
	
		
	}

