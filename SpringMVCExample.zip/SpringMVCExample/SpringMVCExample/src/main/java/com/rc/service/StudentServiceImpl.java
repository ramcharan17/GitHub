package com.rc.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rc.dao.RecordDAO;
import com.rc.entity.Student;

@Service("studService")
public class StudentServiceImpl {
	@Autowired
	private RecordDAO dao;

	public int insert(Student stud) {
		int add = dao.insert(stud);
		return add;
	}

	public List<Map<String,Object>> showAllRecords() {
		List<Map<String, Object>> list = dao.showAllRecords();
		
		return list;
	}

	public int updateRecord(Student stud) {
		int result = dao.updateRecord(stud);
		return result;
	}

	public Student getStudent(int id) {
		Student student = dao.getStudent(id);
		return student;
	}
}
