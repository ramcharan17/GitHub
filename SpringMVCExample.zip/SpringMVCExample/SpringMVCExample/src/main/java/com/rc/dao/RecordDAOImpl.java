package com.rc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.rc.entity.Student;

@Repository("studDAO")
public class RecordDAOImpl implements RecordDAO {
	private static final String INSERT_STUDENT = "INSERT INTO STUDENTS VALUES(?,?,?,?)";
	private static final String SHOW_STUDENT = "SELECT * FROM STUDENTS ";
	private static final String UPDATE_STUDENT = "UPDATE STUDENTS SET NAME=?,GENDER=?,ADDR=? WHERE ID=?";
	private static final String SHOW_ONE_STUDENT = "SELECT * FROM STUDENTS WHERE ID=?";
	@Autowired
	private JdbcTemplate jt;

	public List<Map<String, Object>> showAllRecords() {
		List<Map<String, Object>> list = jt.queryForList(SHOW_STUDENT);
		return list;
	}

	public int insert(Student stud) {
		int cnt = jt.update(INSERT_STUDENT, stud.getId(), stud.getName(), stud.getGender(), stud.getAddr());
		return cnt;
	}

	public int updateRecord(Student stud) {
		int cnt = jt.update(UPDATE_STUDENT, stud.getName(), stud.getGender(), stud.getAddr(),stud.getId());
		return cnt;
	}

	@Override
	public Student getStudent(int id) {
		Student student = null;
		student = jt.queryForObject(SHOW_ONE_STUDENT, new StudentMapper(), id);
		System.out.println(student.toString());
				return student;
	}

	private class StudentMapper implements RowMapper<Student> {

		@Override
		public Student mapRow(ResultSet rs, int index) throws SQLException {
			Student student = null;
		
			student = new Student();
			student.setId(rs.getInt(1));
			student.setName(rs.getString(2));
			student.setAddr(rs.getString(4));
			student.setGender(rs.getString(3));
			return student;
		}
	}// class

}
